#include "omnis.xcomp.framework.h"

#define LIB_RES_NAME    1000            /* Resource id of library name */

#define VERSION_MAJOR            1        // Major Version number - Update on MAJOR release builds
#define VERSION_MINOR            2        // Minor Version number - Update on release builds

#include "opythonobject.h"

extern EXTCompInfo* gECI ;

